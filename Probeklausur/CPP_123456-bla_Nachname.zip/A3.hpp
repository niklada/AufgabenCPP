#include <iostream>
#include <algorithm>
#include <functional>
#include <vector>
#include <sstream>
#include <thread>
#include <string>
#include <mutex>
#include <chrono>
using namespace std;

extern vector<string> Q;
extern stringstream S;
extern thread T;

/***********************************************/
/* Bitte die folgenden Makros einkommentieren, */
/* so bald die entsprechende Unteraufgabe      */
/* gelöst ist !!!                              */
/***********************************************/
//#define A3_a
//#define A3_b
//#define A3_c

#ifdef  A3_a
void start_thread()
{

}
#endif

#ifdef  A3_b
void send_word(const string & s)
{

}
#endif

#ifdef  A3_c
void stop_thread()
{

}
#endif
