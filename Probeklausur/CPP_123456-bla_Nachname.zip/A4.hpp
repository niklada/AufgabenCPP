#include <iostream>
#include <fstream>
#include <algorithm>
#include <functional>
using namespace std;


/***********************************************/
/* Bitte die folgenden Makros einkommentieren, */
/* so bald die entsprechende Unteraufgabe      */
/* gelöst ist !!!                              */
/***********************************************/
//#define A4_a
//#define A4_b
//#define A4_c
//#define A4_d

class add_formel
{
#ifdef  A4_a
// member v
#endif

#ifdef  A4_b
// operator+=
#endif

#ifdef  A4_c
int eval(int)
{
    return 0;
}
#endif

#ifdef  A4_d
// operator()
#endif

};


