// Prüfung C++, Winter 2013/14, Terstegge/Voss

const char * matse_name   = "bla Nachname";
const char * matse_matrnr = "123456";

